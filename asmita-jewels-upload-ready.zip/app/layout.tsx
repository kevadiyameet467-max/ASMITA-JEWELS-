import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Asmita Jewels | Your Story. Our Craftsmanship.', description: 'Made-to-order gold and diamond jewellery, thoughtfully designed around your story.', metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://example.com') };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
