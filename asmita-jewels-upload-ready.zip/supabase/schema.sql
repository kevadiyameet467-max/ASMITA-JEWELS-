create extension if not exists pgcrypto;
create table if not exists public.enquiries (
 id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(),
 name text not null check (char_length(name) between 1 and 100), email text not null check (char_length(email)<=254),
 phone text, kind text not null check (kind in ('design','trade','consult')), category text, budget text,
 metal text, stone text, business text, details text, source text not null default 'website',
 status text not null default 'new' check (status in ('new','contacted','qualified','quoted','closed','spam'))
);
alter table public.enquiries enable row level security;
revoke all on table public.enquiries from anon, authenticated;
grant insert on table public.enquiries to anon, authenticated;
create policy "Website can submit enquiries" on public.enquiries for insert to anon, authenticated
 with check (status='new' and source='website');
-- No public SELECT policy: submitted customer data is not publicly readable.
